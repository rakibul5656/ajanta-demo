import { Feather } from '@expo/vector-icons';
import React, { type ReactNode } from 'react';
import {
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  type ScrollViewProps,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useBusiness } from '@/src/business-context';

const logo = require('../assets/images/ajanta-logo.png');

export function Page({
  children,
  contentContainerStyle,
  ...props
}: ScrollViewProps) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { storageError } = useBusiness();
  return (
    <ScrollView
      style={[styles.page, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.pageContent,
        {
          paddingTop:
            Platform.OS === 'web'
              ? Math.max(insets.top, 67) + 12
              : insets.top + 10,
          paddingBottom: Math.max(insets.bottom, 24) + 92,
        },
        contentContainerStyle,
      ]}
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}
      {...props}
    >
      {storageError ? (
        <View
          style={[
            styles.storageWarning,
            { backgroundColor: '#FBE9E7', borderColor: '#F2C4BF' },
          ]}
        >
          <Feather name="alert-triangle" size={15} color={colors.destructive} />
          <Text style={[styles.storageWarningText, { color: colors.destructive }]}>
            {storageError}
          </Text>
        </View>
      ) : null}
      {children}
    </ScrollView>
  );
}

export function BrandHeader({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={styles.brandHeader}>
      <View style={styles.brandHeading}>
        <Image source={logo} style={styles.logo} />
        <View style={styles.brandText}>
          <Text style={[styles.brandName, { color: colors.foreground }]}>
            Ajanta Shoes
          </Text>
          {subtitle ? (
            <Text style={[styles.brandSubtitle, { color: colors.mutedForeground }]}>
              {subtitle}
            </Text>
          ) : null}
        </View>
      </View>
      {action}
      <Text style={[styles.pageTitle, { color: colors.foreground }]}>{title}</Text>
    </View>
  );
}

export function Panel({
  children,
  style,
}: {
  children: ReactNode;
  style?: object;
}) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.panel,
        { backgroundColor: colors.card, borderColor: colors.border },
        style,
      ]}
    >
      {children}
    </View>
  );
}

export function SectionTitle({
  title,
  action,
}: {
  title: string;
  action?: ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={styles.sectionHeading}>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
        {title}
      </Text>
      {action}
    </View>
  );
}

export function ActionButton({
  title,
  onPress,
  icon,
  secondary = false,
  disabled = false,
  testID,
}: {
  title: string;
  onPress: () => void;
  icon?: React.ComponentProps<typeof Feather>['name'];
  secondary?: boolean;
  disabled?: boolean;
  testID?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      testID={testID}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.actionButton,
        {
          backgroundColor: secondary ? colors.secondary : colors.primary,
          opacity: disabled ? 0.45 : pressed ? 0.82 : 1,
        },
      ]}
    >
      {icon ? (
        <Feather
          name={icon}
          size={16}
          color={secondary ? colors.secondaryForeground : colors.primaryForeground}
        />
      ) : null}
      <Text
        style={[
          styles.actionText,
          {
            color: secondary
              ? colors.secondaryForeground
              : colors.primaryForeground,
          },
        ]}
      >
        {title}
      </Text>
    </Pressable>
  );
}

export function StatusPill({ label }: { label: string }) {
  const colors = useColors();
  const isWarning = ['Confirmed', 'Packed', 'Due', 'Low stock'].includes(label);
  const isDanger = ['Cancelled', 'Overdue'].includes(label);
  return (
    <View
      style={[
        styles.pill,
        {
          backgroundColor: isDanger
            ? '#FBE9E7'
            : isWarning
              ? '#FFF2D8'
              : '#E7F4EC',
        },
      ]}
    >
      <Text
        style={[
          styles.pillText,
          {
            color: isDanger
              ? colors.destructive
              : isWarning
                ? '#9A6500'
                : '#2E7650',
          },
        ]}
      >
        {label}
      </Text>
    </View>
  );
}

export function EmptyState({
  title,
  description,
  icon = 'inbox',
}: {
  title: string;
  description: string;
  icon?: React.ComponentProps<typeof Feather>['name'];
}) {
  const colors = useColors();
  return (
    <View style={styles.emptyState}>
      <View style={[styles.emptyIcon, { backgroundColor: colors.muted }]}>
        <Feather name={icon} size={22} color={colors.mutedForeground} />
      </View>
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.emptyDescription, { color: colors.mutedForeground }]}>
        {description}
      </Text>
    </View>
  );
}

export const uiStyles = StyleSheet.create({
  body: { fontSize: 14, lineHeight: 21 },
  muted: { fontSize: 12, lineHeight: 18 },
  row: { flexDirection: 'row', alignItems: 'center' },
  divider: { height: 1, marginVertical: 14 },
});

const styles = StyleSheet.create({
  page: { flex: 1 },
  pageContent: { paddingHorizontal: 20, gap: 18 },
  brandHeader: { gap: 16, paddingTop: 8 },
  brandHeading: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logo: { width: 37, height: 37, borderRadius: 12 },
  brandText: { flex: 1, gap: 1 },
  brandName: { fontSize: 15, fontWeight: '700', letterSpacing: 0.1 },
  brandSubtitle: { fontSize: 11, fontWeight: '500' },
  pageTitle: { fontSize: 28, lineHeight: 34, fontWeight: '700', letterSpacing: -0.7 },
  panel: {
    borderWidth: 1,
    borderRadius: 18,
    padding: 16,
    shadowColor: '#321919',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.035,
    shadowRadius: 10,
    elevation: 1,
  },
  sectionHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 11,
  },
  sectionTitle: { fontSize: 16, fontWeight: '700', letterSpacing: -0.2 },
  actionButton: {
    minHeight: 46,
    borderRadius: 13,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  actionText: { fontWeight: '700', fontSize: 14 },
  pill: { borderRadius: 99, paddingHorizontal: 10, paddingVertical: 5 },
  pillText: { fontSize: 11, fontWeight: '700' },
  emptyState: { alignItems: 'center', paddingVertical: 26, gap: 8 },
  emptyIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 2,
  },
  emptyTitle: { fontSize: 15, fontWeight: '700', textAlign: 'center' },
  emptyDescription: { fontSize: 13, lineHeight: 19, textAlign: 'center', maxWidth: 250 },
  storageWarning: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    padding: 11,
    borderRadius: 12,
    borderWidth: 1,
  },
  storageWarningText: { flex: 1, fontSize: 11, lineHeight: 16, fontWeight: '600' },
});
