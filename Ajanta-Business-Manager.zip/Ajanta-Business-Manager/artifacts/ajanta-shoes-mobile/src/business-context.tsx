import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import {
  DEMO_DATA,
  customerDue,
  orderTotal,
  type BusinessData,
  type Customer,
  type NewOrderInput,
  type Payment,
  type PaymentMethod,
  type SaleOrder,
} from './business';

const STORAGE_KEY = 'ajanta-shoes-local-v1';

interface BusinessContextValue {
  data: BusinessData;
  isReady: boolean;
  storageError: string | null;
  addCustomer: (input: Omit<Customer, 'id' | 'code'>) => void;
  createOrder: (input: NewOrderInput) => string;
  recordPayment: (
    orderId: string,
    amount: number,
    method: PaymentMethod,
  ) => void;
  updateOrderStatus: (orderId: string, status: SaleOrder['status']) => void;
  adjustStock: (variantId: string, delta: number) => void;
}

const BusinessContext = createContext<BusinessContextValue | null>(null);
const makeId = () =>
  `${Date.now().toString()}${Math.random().toString(36).slice(2, 8)}`;

export function BusinessProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<BusinessData>(DEMO_DATA);
  const dataRef = useRef<BusinessData>(DEMO_DATA);
  const [isReady, setIsReady] = useState(false);
  const [storageError, setStorageError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const stored = await AsyncStorage.getItem(STORAGE_KEY);
        if (stored && active) {
          const parsed = JSON.parse(stored) as BusinessData;
          if (
            Array.isArray(parsed.variants) &&
            Array.isArray(parsed.customers) &&
            Array.isArray(parsed.orders) &&
            Array.isArray(parsed.payments)
          ) {
            dataRef.current = parsed;
            setData(parsed);
          } else {
            await AsyncStorage.removeItem(STORAGE_KEY);
          }
        }
      } catch {
        if (active) {
          setData(DEMO_DATA);
          setStorageError('Saved data could not be read. This session is using sample data.');
        }
        dataRef.current = DEMO_DATA;
      } finally {
        if (active) setIsReady(true);
      }
    };
    void load();
    return () => {
      active = false;
    };
  }, []);

  const commit = useCallback(
    (change: (current: BusinessData) => BusinessData) => {
      const next = change(dataRef.current);
      dataRef.current = next;
      setData(next);
      void AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next)).then(
        () => setStorageError(null),
        () => setStorageError('Changes are not saving to this device. Do not close the app until storage is available.'),
      );
    },
    [],
  );

  const addCustomer = useCallback(
    (input: Omit<Customer, 'id' | 'code'>) => {
      const id = makeId();
      commit((current) => ({
        ...current,
        customers: [
          {
            ...input,
            id,
            code: `C-${String(current.customers.length + 1).padStart(3, '0')}`,
          },
          ...current.customers,
        ],
      }));
    },
    [commit],
  );

  const createOrder = useCallback(
    (input: NewOrderInput) => {
      if (!input.customerId || input.items.length === 0) {
        throw new Error('Choose a customer and add at least one item.');
      }
      const orderId = makeId();
      let orderNumber = '';
      commit((current) => {
        const grouped = new Map<string, number>();
        input.items.forEach((item) =>
          grouped.set(
            item.variantId,
            (grouped.get(item.variantId) ?? 0) + item.quantity,
          ),
        );
        for (const [variantId, quantity] of grouped) {
          const variant = current.variants.find((entry) => entry.id === variantId);
          if (!variant || variant.stock - variant.reserved < quantity) {
            throw new Error('One or more items no longer have enough stock.');
          }
        }
        const sequence =
          current.orders.reduce((highest, order) => {
            const match = order.orderNo.match(/(\d+)$/);
            return Math.max(highest, match ? Number(match[1]) : 0);
          }, 0) + 1;
        orderNumber = `AS-${String(sequence).padStart(5, '0')}`;
        const order: SaleOrder = {
          id: orderId,
          orderNo: orderNumber,
          customerId: input.customerId,
          createdAt: new Date().toISOString(),
          channel: input.channel,
          status: 'Confirmed',
          notes: input.notes.trim(),
          items: input.items.map((item) => {
            const variant = current.variants.find(
              (entry) => entry.id === item.variantId,
            )!;
            return {
              variantId: variant.id,
              sku: variant.sku,
              modelName: variant.modelName,
              color: variant.color,
              size: variant.size,
              quantity: item.quantity,
              unitPrice: item.unitPrice,
              discount: 0,
            };
          }),
        };
        const total = orderTotal(order);
        if (input.initialPayment < 0 || input.initialPayment > total) {
          throw new Error('Payment must be between zero and the order total.');
        }
        const customer = current.customers.find(
          (entry) => entry.id === input.customerId,
        );
        if (!customer) throw new Error('The selected customer no longer exists.');
        const projectedDue =
          customerDue(current, input.customerId) + total - input.initialPayment;
        if (projectedDue > customer.creditLimit) {
          throw new Error(
            `This order would exceed the customer’s ${customer.creditLimit.toLocaleString('en-BD')} BDT credit limit.`,
          );
        }
        const payments: Payment[] =
          input.initialPayment > 0
            ? [
                {
                  id: makeId(),
                  customerId: input.customerId,
                  orderId,
                  amount: input.initialPayment,
                  method: input.paymentMethod,
                  createdAt: new Date().toISOString(),
                },
              ]
            : [];
        return {
          ...current,
          variants: current.variants.map((variant) => ({
            ...variant,
            reserved:
              variant.reserved + (grouped.get(variant.id) ?? 0),
          })),
          orders: [order, ...current.orders],
          payments: [...payments, ...current.payments],
        };
      });
      return orderId;
    },
    [commit],
  );

  const recordPayment = useCallback(
    (orderId: string, amount: number, method: PaymentMethod) => {
      if (!Number.isFinite(amount) || amount <= 0) {
        throw new Error('Enter a payment amount greater than zero.');
      }
      commit((current) => {
        const order = current.orders.find((entry) => entry.id === orderId);
        if (!order || order.status === 'Cancelled') {
          throw new Error('This order cannot receive a payment.');
        }
        const received = current.payments
          .filter((payment) => payment.orderId === orderId)
          .reduce((sum, payment) => sum + payment.amount, 0);
        const due = orderTotal(order) - received;
        if (amount > due) {
          throw new Error('Payment cannot be greater than the remaining due.');
        }
        return {
          ...current,
          payments: [
            {
              id: makeId(),
              customerId: order.customerId,
              orderId,
              amount,
              method,
              createdAt: new Date().toISOString(),
            },
            ...current.payments,
          ],
        };
      });
    },
    [commit],
  );

  const updateOrderStatus = useCallback(
    (orderId: string, status: SaleOrder['status']) => {
      commit((current) => {
        const order = current.orders.find((entry) => entry.id === orderId);
        if (!order) throw new Error('Order not found.');
        if (order.status === 'Delivered' || order.status === 'Cancelled') {
          throw new Error('This order is already closed.');
        }
        if (status === 'Cancelled') {
          if (order.status === 'Dispatched') {
            throw new Error('Dispatched orders cannot be cancelled here.');
          }
          if (current.payments.some((payment) => payment.orderId === orderId)) {
            throw new Error(
              'This order has a posted payment. Record an authorized refund before cancelling it.',
            );
          }
          return {
            ...current,
            orders: current.orders.map((entry) =>
              entry.id === orderId ? { ...entry, status } : entry,
            ),
            variants: current.variants.map((variant) => ({
              ...variant,
              reserved:
                variant.reserved -
                (order.items
                  .filter((line) => line.variantId === variant.id)
                  .reduce((sum, line) => sum + line.quantity, 0) || 0),
            })),
          };
        }
        if (status === 'Delivered' && order.status === 'Dispatched') {
          return {
            ...current,
            orders: current.orders.map((entry) =>
              entry.id === orderId ? { ...entry, status } : entry,
            ),
          };
        }
        if (
          status === 'Packed' &&
          !['Confirmed'].includes(order.status)
        ) {
          throw new Error('Only confirmed orders can be packed.');
        }
        if (status === 'Dispatched' && !['Confirmed', 'Packed'].includes(order.status)) {
          throw new Error('Only confirmed or packed orders can be dispatched.');
        }
        if (status === 'Delivered' && order.status !== 'Dispatched') {
          throw new Error('Dispatch this order before marking it delivered.');
        }
        if (status === 'Dispatched') {
          const quantities = new Map<string, number>();
          order.items.forEach((line) =>
            quantities.set(
              line.variantId,
              (quantities.get(line.variantId) ?? 0) + line.quantity,
            ),
          );
          for (const [variantId, quantity] of quantities) {
            const variant = current.variants.find(
              (entry) => entry.id === variantId,
            );
            if (!variant || variant.reserved < quantity || variant.stock < quantity) {
              throw new Error('Stock reservation is no longer available.');
            }
          }
          return {
            ...current,
            orders: current.orders.map((entry) =>
              entry.id === orderId ? { ...entry, status } : entry,
            ),
            variants: current.variants.map((variant) => {
              const quantity = quantities.get(variant.id) ?? 0;
              return {
                ...variant,
                stock: variant.stock - quantity,
                reserved: variant.reserved - quantity,
              };
            }),
          };
        }
        return {
          ...current,
          orders: current.orders.map((entry) =>
            entry.id === orderId ? { ...entry, status } : entry,
          ),
        };
      });
    },
    [commit],
  );

  const adjustStock = useCallback(
    (variantId: string, delta: number) => {
      if (!Number.isFinite(delta) || delta === 0) {
        throw new Error('Enter a stock adjustment greater than zero or less than zero.');
      }
      commit((current) => ({
        ...current,
        variants: current.variants.map((variant) => {
          if (variant.id !== variantId) return variant;
          if (variant.stock + delta < variant.reserved) {
            throw new Error('Stock cannot be lower than reserved stock.');
          }
          return { ...variant, stock: variant.stock + delta };
        }),
      }));
    },
    [commit],
  );

  const value = useMemo(
    () => ({
      data,
      isReady,
      storageError,
      addCustomer,
      createOrder,
      recordPayment,
      updateOrderStatus,
      adjustStock,
    }),
    [
      data,
      isReady,
      storageError,
      addCustomer,
      createOrder,
      recordPayment,
      updateOrderStatus,
      adjustStock,
    ],
  );

  return (
    <BusinessContext.Provider value={value}>{children}</BusinessContext.Provider>
  );
}

export function useBusiness() {
  const context = useContext(BusinessContext);
  if (!context) throw new Error('useBusiness must be used inside BusinessProvider.');
  return context;
}
