export type OrderStatus =
  | 'Confirmed'
  | 'Packed'
  | 'Dispatched'
  | 'Delivered'
  | 'Cancelled';

export type PaymentMethod = 'Cash' | 'Bank' | 'bKash' | 'Nagad' | 'Other';

export interface ProductVariant {
  id: string;
  modelCode: string;
  modelName: string;
  category: string;
  color: string;
  size: string;
  sku: string;
  stock: number;
  reserved: number;
  cost: number;
  wholesalePrice: number;
}

export interface Customer {
  id: string;
  code: string;
  name: string;
  phone: string;
  address: string;
  creditLimit: number;
  openingDue: number;
}

export interface OrderLine {
  variantId: string;
  sku: string;
  modelName: string;
  color: string;
  size: string;
  quantity: number;
  unitPrice: number;
  discount: number;
}

export interface SaleOrder {
  id: string;
  orderNo: string;
  customerId: string;
  createdAt: string;
  channel: 'Showroom' | 'Phone';
  status: OrderStatus;
  items: OrderLine[];
  notes: string;
}

export interface Payment {
  id: string;
  customerId: string;
  orderId: string;
  amount: number;
  method: PaymentMethod;
  createdAt: string;
}

export interface BusinessData {
  variants: ProductVariant[];
  customers: Customer[];
  orders: SaleOrder[];
  payments: Payment[];
}

export interface NewOrderInput {
  customerId: string;
  channel: SaleOrder['channel'];
  notes: string;
  items: Array<{ variantId: string; quantity: number; unitPrice: number }>;
  initialPayment: number;
  paymentMethod: PaymentMethod;
}

const today = new Date();
const minutesAgo = (minutes: number) =>
  new Date(today.getTime() - minutes * 60_000).toISOString();

export const DEMO_DATA: BusinessData = {
  variants: [
    {
      id: 'v1',
      modelCode: 'AJ-101',
      modelName: 'Classic Runner',
      category: 'Casual',
      color: 'Black',
      size: '40',
      sku: 'AJ-101-BLK-40',
      stock: 36,
      reserved: 4,
      cost: 640,
      wholesalePrice: 850,
    },
    {
      id: 'v2',
      modelCode: 'AJ-101',
      modelName: 'Classic Runner',
      category: 'Casual',
      color: 'Black',
      size: '41',
      sku: 'AJ-101-BLK-41',
      stock: 28,
      reserved: 0,
      cost: 640,
      wholesalePrice: 850,
    },
    {
      id: 'v3',
      modelCode: 'AJ-101',
      modelName: 'Classic Runner',
      category: 'Casual',
      color: 'Brown',
      size: '40',
      sku: 'AJ-101-BRN-40',
      stock: 4,
      reserved: 0,
      cost: 650,
      wholesalePrice: 880,
    },
    {
      id: 'v4',
      modelCode: 'AJ-220',
      modelName: 'Office Formal',
      category: 'Formal',
      color: 'Tan',
      size: '42',
      sku: 'AJ-220-TAN-42',
      stock: 3,
      reserved: 0,
      cost: 920,
      wholesalePrice: 1_250,
    },
    {
      id: 'v5',
      modelCode: 'AJ-305',
      modelName: 'Everyday Sandal',
      category: 'Sandals',
      color: 'Navy',
      size: '41',
      sku: 'AJ-305-NVY-41',
      stock: 22,
      reserved: 0,
      cost: 390,
      wholesalePrice: 560,
    },
  ],
  customers: [
    {
      id: 'c1',
      code: 'C-001',
      name: 'M/S Rahman Footwear',
      phone: '01712 345 678',
      address: 'New Market, Dhaka',
      creditLimit: 30_000,
      openingDue: 2_500,
    },
    {
      id: 'c2',
      code: 'C-002',
      name: 'City Shoe House',
      phone: '01819 234 567',
      address: 'Mirpur 10, Dhaka',
      creditLimit: 20_000,
      openingDue: 0,
    },
    {
      id: 'c3',
      code: 'C-003',
      name: 'Bismillah Traders',
      phone: '01911 876 543',
      address: 'Gulistan, Dhaka',
      creditLimit: 25_000,
      openingDue: 1_200,
    },
  ],
  orders: [
    {
      id: 'o1',
      orderNo: 'AS-26001',
      customerId: 'c1',
      createdAt: minutesAgo(95),
      channel: 'Showroom',
      status: 'Confirmed',
      notes: 'Call before delivery',
      items: [
        {
          variantId: 'v1',
          sku: 'AJ-101-BLK-40',
          modelName: 'Classic Runner',
          color: 'Black',
          size: '40',
          quantity: 4,
          unitPrice: 850,
          discount: 0,
        },
      ],
    },
    {
      id: 'o2',
      orderNo: 'AS-26000',
      customerId: 'c2',
      createdAt: minutesAgo(250),
      channel: 'Phone',
      status: 'Delivered',
      notes: '',
      items: [
        {
          variantId: 'v2',
          sku: 'AJ-101-BLK-41',
          modelName: 'Classic Runner',
          color: 'Black',
          size: '41',
          quantity: 6,
          unitPrice: 850,
          discount: 100,
        },
        {
          variantId: 'v5',
          sku: 'AJ-305-NVY-41',
          modelName: 'Everyday Sandal',
          color: 'Navy',
          size: '41',
          quantity: 2,
          unitPrice: 560,
          discount: 0,
        },
      ],
    },
    {
      id: 'o3',
      orderNo: 'AS-25998',
      customerId: 'c3',
      createdAt: minutesAgo(1_440 * 2),
      channel: 'Showroom',
      status: 'Packed',
      notes: '',
      items: [
        {
          variantId: 'v4',
          sku: 'AJ-220-TAN-42',
          modelName: 'Office Formal',
          color: 'Tan',
          size: '42',
          quantity: 2,
          unitPrice: 1_250,
          discount: 0,
        },
      ],
    },
  ],
  payments: [
    {
      id: 'p1',
      customerId: 'c2',
      orderId: 'o2',
      amount: 3_000,
      method: 'bKash',
      createdAt: minutesAgo(240),
    },
  ],
};

export const formatBDT = (amount: number) =>
  `৳${Math.round(amount).toLocaleString('en-BD')}`;

const dhakaDateKey = (date: Date) =>
  new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Dhaka',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);

export const isTodayInDhaka = (date: Date) =>
  dhakaDateKey(date) === dhakaDateKey(new Date());

export const businessMonthKey = (date: Date) => dhakaDateKey(date).slice(0, 7);

export const formatBusinessDate = (date: Date, options?: Intl.DateTimeFormatOptions) =>
  new Intl.DateTimeFormat('en-BD', {
    timeZone: 'Asia/Dhaka',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    ...options,
  }).format(date);

export const orderTotal = (order: SaleOrder) =>
  order.items.reduce(
    (total, line) =>
      total + Math.max(0, line.unitPrice - line.discount) * line.quantity,
    0,
  );

export const paidForOrder = (data: BusinessData, orderId: string) =>
  data.payments
    .filter((payment) => payment.orderId === orderId)
    .reduce((sum, payment) => sum + payment.amount, 0);

export const customerDue = (data: BusinessData, customerId: string) => {
  const customer = data.customers.find((entry) => entry.id === customerId);
  const sales = data.orders
    .filter(
      (order) => order.customerId === customerId && order.status !== 'Cancelled',
    )
    .reduce((sum, order) => sum + orderTotal(order), 0);
  const received = data.payments
    .filter((payment) => payment.customerId === customerId)
    .reduce((sum, payment) => sum + payment.amount, 0);
  return Math.max(0, (customer?.openingDue ?? 0) + sales - received);
};
