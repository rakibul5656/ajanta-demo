import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import {
  Keyboard,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import { useBusiness } from '@/src/business-context';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function NewCustomerScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { addCustomer } = useBusiness();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [creditLimit, setCreditLimit] = useState('');
  const [error, setError] = useState('');

  const save = () => {
    const cleanName = name.trim();
    const cleanPhone = phone.trim();
    const limit = creditLimit.trim() ? Number(creditLimit) : 0;
    if (!cleanName) return setError('Enter the shop or customer name.');
    if (!cleanPhone || cleanPhone.replace(/\D/g, '').length < 7) {
      return setError('Enter a valid contact number.');
    }
    if (!Number.isFinite(limit) || limit < 0) {
      return setError('Credit limit must be zero or a positive amount.');
    }
    addCustomer({
      name: cleanName,
      phone: cleanPhone,
      address: address.trim(),
      creditLimit: limit,
      openingDue: 0,
    });
    Keyboard.dismiss();
    router.back();
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.topBar,
          {
            paddingTop: Platform.OS === 'web' ? 67 : insets.top + 12,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Go back"
          onPress={() => router.back()}
          style={styles.backButton}
        >
          <Feather name="arrow-left" size={20} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.topTitle, { color: colors.foreground }]}>New customer</Text>
        <View style={{ width: 40 }} />
      </View>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingTop: 23,
          paddingBottom: 36,
          gap: 17,
        }}
        bottomOffset={76}
        keyboardShouldPersistTaps="handled"
      >
        <View style={[styles.introIcon, { backgroundColor: colors.accent }]}>
          <Feather name="user-plus" size={21} color={colors.primary} />
        </View>
        <View style={{ gap: 5 }}>
          <Text style={[styles.heading, { color: colors.foreground }]}>
            Add a wholesale account
          </Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            A customer code will be assigned automatically.
          </Text>
        </View>
        <Field
          label="Shop / customer name"
          placeholder="e.g. Rahman Footwear"
          value={name}
          onChangeText={setName}
          autoCapitalize="words"
          required
        />
        <Field
          label="Phone number"
          placeholder="01XXX XXXXXX"
          value={phone}
          onChangeText={setPhone}
          keyboardType="phone-pad"
          required
        />
        <Field
          label="Address"
          placeholder="Market, area, city"
          value={address}
          onChangeText={setAddress}
          autoCapitalize="words"
        />
        <Field
          label="Credit limit"
          placeholder="0"
          value={creditLimit}
          onChangeText={setCreditLimit}
          keyboardType="decimal-pad"
          helper="Optional · amount in Bangladeshi Taka"
        />
        {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
        <Pressable
          accessibilityRole="button"
          testID="customer-save"
          onPress={save}
          style={({ pressed }) => [
            styles.saveButton,
            { backgroundColor: colors.primary, opacity: pressed ? 0.82 : 1 },
          ]}
        >
          <Feather name="check" size={18} color="#FFFFFF" />
          <Text style={styles.saveText}>Save customer</Text>
        </Pressable>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

function Field({
  label,
  helper,
  required,
  ...inputProps
}: React.ComponentProps<typeof TextInput> & {
  label: string;
  helper?: string;
  required?: boolean;
}) {
  const colors = useColors();
  return (
    <View style={{ gap: 7 }}>
      <Text style={[styles.fieldLabel, { color: colors.foreground }]}>
        {label}
        {required ? ' *' : ''}
      </Text>
      <TextInput
        {...inputProps}
        placeholderTextColor={colors.mutedForeground}
        style={[
          styles.input,
          { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border },
        ]}
      />
      {helper ? <Text style={[styles.helper, { color: colors.mutedForeground }]}>{helper}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  topBar: {
    minHeight: 59,
    paddingHorizontal: 18,
    paddingBottom: 12,
    borderBottomWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  topTitle: { fontSize: 16, fontWeight: '700' },
  introIcon: { width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  heading: { fontSize: 23, fontWeight: '700', letterSpacing: -0.5 },
  subtitle: { fontSize: 13, lineHeight: 20 },
  fieldLabel: { fontSize: 13, fontWeight: '700' },
  input: { minHeight: 50, borderWidth: 1, borderRadius: 13, paddingHorizontal: 14, fontSize: 14 },
  helper: { fontSize: 11 },
  error: { fontSize: 12, fontWeight: '600' },
  saveButton: { minHeight: 50, borderRadius: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 2 },
  saveText: { color: '#FFFFFF', fontSize: 14, fontWeight: '700' },
});
