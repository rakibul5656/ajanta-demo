import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useMemo, useState } from 'react';
import {
  Keyboard,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import { useBusiness } from '@/src/business-context';
import { formatBDT, type PaymentMethod } from '@/src/business';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const paymentMethods: PaymentMethod[] = ['Cash', 'Bank', 'bKash', 'Nagad', 'Other'];

export default function NewOrderScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { data, createOrder } = useBusiness();
  const [customerId, setCustomerId] = useState('');
  const [channel, setChannel] = useState<'Showroom' | 'Phone'>('Showroom');
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [initialPayment, setInitialPayment] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');

  const lines = useMemo(
    () =>
      data.variants
        .filter((variant) => (quantities[variant.id] ?? 0) > 0)
        .map((variant) => ({
          variantId: variant.id,
          quantity: quantities[variant.id],
          unitPrice: variant.wholesalePrice,
          variant,
        })),
    [data.variants, quantities],
  );
  const total = lines.reduce(
    (sum, line) => sum + line.quantity * line.unitPrice,
    0,
  );
  const availableToSell = (variantId: string) => {
    const variant = data.variants.find((entry) => entry.id === variantId);
    return variant ? variant.stock - variant.reserved : 0;
  };

  const changeQuantity = (variantId: string, delta: number) => {
    setError('');
    setQuantities((current) => {
      const next = Math.max(0, (current[variantId] ?? 0) + delta);
      return { ...current, [variantId]: Math.min(next, availableToSell(variantId)) };
    });
  };

  const save = () => {
    setError('');
    const payment = initialPayment.trim() ? Number(initialPayment) : 0;
    if (!customerId) return setError('Select a customer before creating the order.');
    if (!lines.length) return setError('Add at least one product variant.');
    if (!Number.isFinite(payment) || payment < 0 || payment > total) {
      return setError('Enter a valid initial payment not exceeding the order total.');
    }
    try {
      const id = createOrder({
        customerId,
        channel,
        notes,
        items: lines.map(({ variantId, quantity, unitPrice }) => ({
          variantId,
          quantity,
          unitPrice,
        })),
        initialPayment: payment,
        paymentMethod,
      });
      Keyboard.dismiss();
      router.replace(`/order/${id}`);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Could not create order.');
    }
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.topBar,
          {
            paddingTop: Platform.OS === 'web' ? 67 : insets.top + 12,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Go back"
          onPress={() => router.back()}
          style={styles.backButton}
        >
          <Feather name="arrow-left" size={20} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.topTitle, { color: colors.foreground }]}>New sale</Text>
        <View style={{ width: 40 }} />
      </View>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={{
          paddingHorizontal: 18,
          paddingTop: 18,
          paddingBottom: 130,
          gap: 17,
        }}
        bottomOffset={84}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.headingRow}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.heading, { color: colors.foreground }]}>Create an order</Text>
            <Text style={[styles.subheading, { color: colors.mutedForeground }]}>
              Stock is reserved when the order is saved.
            </Text>
          </View>
          <View style={[styles.channelToggle, { backgroundColor: colors.muted }]}>
            {(['Showroom', 'Phone'] as const).map((value) => (
              <Pressable
                key={value}
                accessibilityRole="button"
                accessibilityState={{ selected: channel === value }}
                onPress={() => setChannel(value)}
                style={[
                  styles.channelButton,
                  channel === value && { backgroundColor: colors.card },
                ]}
              >
                <Text style={{ color: channel === value ? colors.foreground : colors.mutedForeground, fontSize: 11, fontWeight: '700' }}>
                  {value}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <SectionHeading number="01" label="Select customer" />
          {data.customers.length ? (
            <View style={{ gap: 8 }}>
              {data.customers.map((customer) => {
                const selected = customerId === customer.id;
                return (
                  <Pressable
                    key={customer.id}
                    accessibilityRole="button"
                    accessibilityState={{ selected }}
                    onPress={() => setCustomerId(customer.id)}
                    style={[
                      styles.customerOption,
                      {
                        backgroundColor: selected ? colors.accent : colors.card,
                        borderColor: selected ? colors.primary : colors.border,
                      },
                    ]}
                  >
                    <View
                      style={[
                        styles.radio,
                        { borderColor: selected ? colors.primary : colors.border },
                      ]}
                    >
                      {selected ? <View style={[styles.radioDot, { backgroundColor: colors.primary }]} /> : null}
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.customerName, { color: colors.foreground }]}>{customer.name}</Text>
                      <Text style={[styles.customerPhone, { color: colors.mutedForeground }]}>{customer.phone}</Text>
                    </View>
                  </Pressable>
                );
              })}
            </View>
          ) : (
            <Pressable onPress={() => router.push('/new-customer')}>
              <Text style={{ color: colors.primary, fontWeight: '700' }}>Add a customer first</Text>
            </Pressable>
          )}
          <Pressable
            accessibilityRole="button"
            onPress={() => router.push('/new-customer')}
            style={styles.addCustomerLink}
          >
            <Feather name="user-plus" size={15} color={colors.primary} />
            <Text style={{ color: colors.primary, fontSize: 12, fontWeight: '700' }}>Add customer</Text>
          </Pressable>
        </View>

        <View style={styles.section}>
          <SectionHeading number="02" label="Add footwear" />
          {data.variants.map((variant) => {
            const available = availableToSell(variant.id);
            const quantity = quantities[variant.id] ?? 0;
            return (
              <View
                key={variant.id}
                style={[
                  styles.variantRow,
                  { borderColor: colors.border, backgroundColor: colors.card },
                ]}
              >
                <View style={[styles.productGlyph, { backgroundColor: colors.accent }]}>
                  <Feather name="package" size={17} color={colors.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.productName, { color: colors.foreground }]}>{variant.modelName}</Text>
                  <Text style={[styles.productDetail, { color: colors.mutedForeground }]}>
                    {variant.color} · size {variant.size} · {available} available
                  </Text>
                  <Text style={[styles.productPrice, { color: colors.foreground }]}>
                    {formatBDT(variant.wholesalePrice)} / pair
                  </Text>
                </View>
                <View style={styles.quantityControl}>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={`Remove one ${variant.modelName} size ${variant.size}`}
                    testID={`order-minus-${variant.id}`}
                    disabled={quantity === 0}
                    onPress={() => changeQuantity(variant.id, -1)}
                    style={[styles.quantityButton, { backgroundColor: colors.muted, opacity: quantity === 0 ? 0.45 : 1 }]}
                  >
                    <Feather name="minus" size={14} color={colors.foreground} />
                  </Pressable>
                  <Text style={[styles.quantityValue, { color: colors.foreground }]}>{quantity}</Text>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={`Add one ${variant.modelName} size ${variant.size}`}
                    testID={`order-plus-${variant.id}`}
                    disabled={quantity >= available}
                    onPress={() => changeQuantity(variant.id, 1)}
                    style={[styles.quantityButton, { backgroundColor: colors.primary, opacity: quantity >= available ? 0.4 : 1 }]}
                  >
                    <Feather name="plus" size={14} color="#FFFFFF" />
                  </Pressable>
                </View>
              </View>
            );
          })}
        </View>

        {lines.length ? (
          <View style={[styles.totalCard, { backgroundColor: '#8D171D' }]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.totalLabel}>ORDER TOTAL</Text>
              <Text style={styles.totalPairs}>{lines.reduce((sum, line) => sum + line.quantity, 0)} pairs</Text>
            </View>
            <Text style={styles.totalAmount}>{formatBDT(total)}</Text>
          </View>
        ) : null}

        <View style={styles.section}>
          <SectionHeading number="03" label="Payment & notes" />
          <Field
            label="Payment received now"
            placeholder="0"
            value={initialPayment}
            onChangeText={setInitialPayment}
            keyboardType="decimal-pad"
            helper={`Remaining due: ${formatBDT(Math.max(0, total - (Number(initialPayment) || 0)))}`}
          />
          {Number(initialPayment) > 0 ? (
            <View style={styles.methodWrap}>
              {paymentMethods.map((method) => (
                <Pressable
                  key={method}
                  onPress={() => setPaymentMethod(method)}
                  style={[
                    styles.methodPill,
                    {
                      backgroundColor: paymentMethod === method ? colors.primary : colors.card,
                      borderColor: paymentMethod === method ? colors.primary : colors.border,
                    },
                  ]}
                >
                  <Text style={{ color: paymentMethod === method ? '#FFFFFF' : colors.foreground, fontSize: 11, fontWeight: '700' }}>
                    {method}
                  </Text>
                </Pressable>
              ))}
            </View>
          ) : null}
          <Field
            label="Order notes"
            placeholder="Delivery details or customer instructions"
            value={notes}
            onChangeText={setNotes}
            multiline
          />
        </View>
        {error ? (
          <View style={[styles.errorBox, { backgroundColor: '#FBE9E7' }]}>
            <Feather name="alert-circle" size={15} color={colors.destructive} />
            <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
          </View>
        ) : null}
        <Pressable
          accessibilityRole="button"
          testID="order-submit"
          onPress={save}
          style={({ pressed }) => [
            styles.submitButton,
            { backgroundColor: colors.primary, opacity: pressed ? 0.82 : 1 },
          ]}
        >
          <Feather name="check" size={18} color="#FFFFFF" />
          <Text style={styles.submitText}>Confirm order</Text>
        </Pressable>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

function SectionHeading({ number, label }: { number: string; label: string }) {
  const colors = useColors();
  return (
    <View style={styles.sectionHeading}>
      <Text style={[styles.sectionNumber, { color: colors.primary }]}>{number}</Text>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{label}</Text>
    </View>
  );
}

function Field({
  label,
  helper,
  ...inputProps
}: React.ComponentProps<typeof TextInput> & { label: string; helper?: string }) {
  const colors = useColors();
  return (
    <View style={{ gap: 7 }}>
      <Text style={[styles.fieldLabel, { color: colors.foreground }]}>{label}</Text>
      <TextInput
        {...inputProps}
        placeholderTextColor={colors.mutedForeground}
        style={[
          styles.input,
          { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border },
          inputProps.multiline && styles.notesInput,
        ]}
      />
      {helper ? <Text style={[styles.helper, { color: colors.mutedForeground }]}>{helper}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  topBar: {
    minHeight: 59,
    paddingHorizontal: 18,
    paddingBottom: 12,
    borderBottomWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  topTitle: { fontSize: 16, fontWeight: '700' },
  headingRow: { gap: 12 },
  heading: { fontSize: 23, fontWeight: '700', letterSpacing: -0.5 },
  subheading: { fontSize: 12, marginTop: 4, lineHeight: 18 },
  channelToggle: { flexDirection: 'row', borderRadius: 12, padding: 3, alignSelf: 'flex-start' },
  channelButton: { minWidth: 86, borderRadius: 9, paddingHorizontal: 12, paddingVertical: 8, alignItems: 'center' },
  section: { gap: 11 },
  sectionHeading: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 1 },
  sectionNumber: { fontSize: 10, fontWeight: '800', letterSpacing: 0.7 },
  sectionTitle: { fontSize: 15, fontWeight: '700' },
  customerOption: { minHeight: 59, borderWidth: 1, borderRadius: 13, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 10 },
  radio: { width: 18, height: 18, borderRadius: 9, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  radioDot: { width: 9, height: 9, borderRadius: 5 },
  customerName: { fontSize: 12, fontWeight: '700' },
  customerPhone: { fontSize: 10, marginTop: 4 },
  addCustomerLink: { flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start', paddingVertical: 3 },
  variantRow: { borderWidth: 1, borderRadius: 14, padding: 10, flexDirection: 'row', alignItems: 'center', gap: 9 },
  productGlyph: { width: 35, height: 35, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  productName: { fontSize: 12, fontWeight: '700' },
  productDetail: { fontSize: 10, marginTop: 3 },
  productPrice: { fontSize: 10, fontWeight: '600', marginTop: 4 },
  quantityControl: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  quantityButton: { width: 27, height: 27, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  quantityValue: { minWidth: 17, textAlign: 'center', fontSize: 12, fontWeight: '700' },
  totalCard: { flexDirection: 'row', alignItems: 'center', padding: 16, borderRadius: 15 },
  totalLabel: { color: '#F3CFCA', fontSize: 10, fontWeight: '700', letterSpacing: 1 },
  totalPairs: { color: '#E8B8B5', fontSize: 11, marginTop: 4 },
  totalAmount: { color: '#FFFFFF', fontSize: 22, fontWeight: '700' },
  fieldLabel: { fontSize: 12, fontWeight: '700' },
  input: { minHeight: 48, borderWidth: 1, borderRadius: 13, paddingHorizontal: 13, fontSize: 13 },
  notesInput: { minHeight: 76, paddingTop: 12, textAlignVertical: 'top' },
  helper: { fontSize: 10 },
  methodWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginTop: -2 },
  methodPill: { borderWidth: 1, borderRadius: 25, paddingHorizontal: 11, paddingVertical: 8 },
  errorBox: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, padding: 11, borderRadius: 12 },
  errorText: { flex: 1, fontSize: 12, lineHeight: 17, fontWeight: '600' },
  submitButton: { minHeight: 51, borderRadius: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  submitText: { color: '#FFFFFF', fontSize: 14, fontWeight: '700' },
});
