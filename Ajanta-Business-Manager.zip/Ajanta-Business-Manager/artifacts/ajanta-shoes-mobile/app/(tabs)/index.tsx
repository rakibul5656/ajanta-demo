import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useMemo } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { useBusiness } from '@/src/business-context';
import {
  businessMonthKey,
  customerDue,
  formatBDT,
  isTodayInDhaka,
  orderTotal,
} from '@/src/business';
import {
  ActionButton,
  BrandHeader,
  EmptyState,
  Page,
  Panel,
  SectionTitle,
  StatusPill,
} from '@/src/ui';

export default function DashboardScreen() {
  const colors = useColors();
  const { data, isReady } = useBusiness();
  const metrics = useMemo(() => {
    const now = new Date();
    const monthOrders = data.orders.filter((order) => {
      const date = new Date(order.createdAt);
      return (
        businessMonthKey(date) === businessMonthKey(now) &&
        ['Dispatched', 'Delivered'].includes(order.status) &&
        order.status !== 'Cancelled'
      );
    });
    const todayOrders = monthOrders.filter((order) =>
      isTodayInDhaka(new Date(order.createdAt)),
    );
    return {
      today: todayOrders.reduce((sum, order) => sum + orderTotal(order), 0),
      month: monthOrders.reduce((sum, order) => sum + orderTotal(order), 0),
      collected: data.payments
        .filter((payment) => {
          return businessMonthKey(new Date(payment.createdAt)) === businessMonthKey(now);
        })
        .reduce((sum, payment) => sum + payment.amount, 0),
      due: data.customers.reduce(
        (sum, customer) => sum + customerDue(data, customer.id),
        0,
      ),
      pairs: data.variants.reduce((sum, variant) => sum + variant.stock, 0),
      pending: data.orders.filter((order) =>
        ['Confirmed', 'Packed'].includes(order.status),
      ).length,
    };
  }, [data]);
  const recentOrders = data.orders.slice(0, 3);
  const lowStock = data.variants
    .filter((variant) => variant.stock - variant.reserved <= 5)
    .slice(0, 3);

  return (
    <Page>
      <BrandHeader
        title="Good morning"
        subtitle="Dhaka Trade Center · Gulistan"
        action={
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Create new sale"
            testID="dashboard-create-sale"
            onPress={() => router.push('/new-order')}
            style={({ pressed }) => [
              styles.headerButton,
              { backgroundColor: colors.primary, opacity: pressed ? 0.8 : 1 },
            ]}
          >
            <Feather name="plus" size={20} color={colors.primaryForeground} />
          </Pressable>
        }
      />

      <View
        style={[
          styles.demoNote,
          { backgroundColor: '#FFF2D8', borderColor: '#F0D9A7' },
        ]}
      >
        <Feather name="info" size={15} color="#986200" />
        <Text style={styles.demoText}>
          Sample workspace · saved only on this device
        </Text>
      </View>

      <Panel style={styles.hero}>
        <View style={styles.heroTop}>
          <View style={{ flex: 1 }}>
            <Text style={styles.heroEyebrow}>TODAY&apos;S SALES</Text>
            <Text style={styles.heroAmount}>
              {isReady ? formatBDT(metrics.today) : '—'}
            </Text>
          </View>
          <View style={styles.heroIcon}>
            <Feather name="trending-up" size={20} color="#FFFFFF" />
          </View>
        </View>
        <View style={styles.heroDivider} />
        <View style={styles.heroBottom}>
          <View>
            <Text style={styles.heroSmallLabel}>This month</Text>
            <Text style={styles.heroSmallValue}>{formatBDT(metrics.month)}</Text>
          </View>
          <View style={styles.heroSplit} />
          <View>
            <Text style={styles.heroSmallLabel}>Collected</Text>
            <Text style={styles.heroSmallValue}>
              {formatBDT(metrics.collected)}
            </Text>
          </View>
        </View>
      </Panel>

      <View style={styles.statRow}>
        <Panel style={styles.statCard}>
          <View style={[styles.statIcon, { backgroundColor: '#F9E9E6' }]}>
            <Feather name="credit-card" size={17} color={colors.primary} />
          </View>
          <Text style={[styles.statValue, { color: colors.foreground }]}>
            {formatBDT(metrics.due)}
          </Text>
          <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>
            Customer due
          </Text>
        </Panel>
        <Panel style={styles.statCard}>
          <View style={[styles.statIcon, { backgroundColor: '#E8F2EC' }]}>
            <Feather name="package" size={17} color="#397654" />
          </View>
          <Text style={[styles.statValue, { color: colors.foreground }]}>
            {metrics.pairs.toLocaleString('en-BD')}
          </Text>
          <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>
            Pairs in stock
          </Text>
        </Panel>
      </View>

      <View style={styles.quickActions}>
        <SectionTitle title="Quick actions" />
        <View style={styles.actionRow}>
          <QuickAction
            icon="plus-square"
            label="New sale"
            onPress={() => router.push('/new-order')}
          />
          <QuickAction
            icon="user-plus"
            label="Add customer"
            onPress={() => router.push('/new-customer')}
          />
          <QuickAction
            icon="file-text"
            label={`${metrics.pending} pending`}
            onPress={() => router.navigate('/(tabs)/orders')}
          />
        </View>
      </View>

      <Panel>
        <SectionTitle
          title="Recent orders"
          action={
            <Pressable onPress={() => router.navigate('/(tabs)/orders')}>
              <Text style={[styles.link, { color: colors.primary }]}>
                View all
              </Text>
            </Pressable>
          }
        />
        {recentOrders.length ? (
          recentOrders.map((order, index) => {
            const customer = data.customers.find(
              (entry) => entry.id === order.customerId,
            );
            return (
              <Pressable
                key={order.id}
                onPress={() => router.push(`/order/${order.id}`)}
                style={[
                  styles.orderRow,
                  index < recentOrders.length - 1 && {
                    borderBottomWidth: 1,
                    borderBottomColor: colors.border,
                  },
                ]}
              >
                <View
                  style={[styles.orderDot, { backgroundColor: colors.accent }]}
                />
                <View style={styles.orderDetails}>
                  <Text
                    style={[
                      styles.orderCustomer,
                      { color: colors.foreground },
                    ]}
                  >
                    {customer?.name ?? 'Customer'}
                  </Text>
                  <Text
                    style={[
                      styles.orderMeta,
                      { color: colors.mutedForeground },
                    ]}
                  >
                    {order.orderNo} ·{' '}
                    {new Date(order.createdAt).toLocaleTimeString('en-BD', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </Text>
                </View>
                <View style={styles.orderTrailing}>
                  <Text
                    style={[styles.orderAmount, { color: colors.foreground }]}
                  >
                    {formatBDT(orderTotal(order))}
                  </Text>
                  <StatusPill label={order.status} />
                </View>
              </Pressable>
            );
          })
        ) : (
          <EmptyState
            title="No sales yet"
            description="Create your first order to get started."
          />
        )}
      </Panel>

      <Panel>
        <SectionTitle
          title="Needs attention"
          action={
            <Pressable onPress={() => router.navigate('/(tabs)/stock')}>
              <Text style={[styles.link, { color: colors.primary }]}>
                All stock
              </Text>
            </Pressable>
          }
        />
        {lowStock.length ? (
          lowStock.map((variant, index) => (
            <View
              key={variant.id}
              style={[
                styles.lowStockRow,
                index > 0 && {
                  borderTopWidth: 1,
                  borderTopColor: colors.border,
                },
              ]}
            >
              <View style={styles.shoeIcon}>
                <Feather name="package" size={16} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={[styles.orderCustomer, { color: colors.foreground }]}
                >
                  {variant.modelName}
                </Text>
                <Text
                  style={[
                    styles.orderMeta,
                    { color: colors.mutedForeground },
                  ]}
                >
                  {variant.color} · size {variant.size}
                </Text>
              </View>
              <StatusPill label="Low stock" />
            </View>
          ))
        ) : (
          <Text style={[styles.noAlert, { color: colors.mutedForeground }]}>
            No low-stock items right now.
          </Text>
        )}
      </Panel>

      <ActionButton
        title="Create a sale"
        icon="plus"
        testID="dashboard-new-order"
        onPress={() => router.push('/new-order')}
      />
    </Page>
  );
}

function QuickAction({
  icon,
  label,
  onPress,
}: {
  icon: React.ComponentProps<typeof Feather>['name'];
  label: string;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [
        styles.quickAction,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          opacity: pressed ? 0.72 : 1,
        },
      ]}
    >
      <Feather name={icon} size={19} color={colors.primary} />
      <Text style={[styles.quickLabel, { color: colors.foreground }]}>
        {label}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  headerButton: {
    width: 40,
    height: 40,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  demoNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 11,
    borderRadius: 12,
    borderWidth: 1,
  },
  demoText: { color: '#815500', fontSize: 12, fontWeight: '600' },
  hero: {
    backgroundColor: '#8D171D',
    borderColor: '#8D171D',
    padding: 20,
    gap: 14,
  },
  heroTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  heroEyebrow: {
    color: '#F3CFCA',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.2,
  },
  heroAmount: {
    color: '#FFFFFF',
    fontSize: 34,
    fontWeight: '700',
    letterSpacing: -0.7,
    marginTop: 6,
  },
  heroIcon: {
    width: 42,
    height: 42,
    borderRadius: 15,
    backgroundColor: '#A53036',
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroDivider: { height: 1, backgroundColor: '#AA363B' },
  heroBottom: { flexDirection: 'row', alignItems: 'center', gap: 20 },
  heroSmallLabel: { color: '#E8B8B5', fontSize: 11, marginBottom: 4 },
  heroSmallValue: { color: '#FFFFFF', fontSize: 14, fontWeight: '700' },
  heroSplit: { width: 1, height: 30, backgroundColor: '#AA363B' },
  statRow: { flexDirection: 'row', gap: 12 },
  statCard: {
    flex: 1,
    padding: 14,
    minHeight: 124,
    justifyContent: 'space-between',
  },
  statIcon: {
    width: 34,
    height: 34,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statValue: {
    fontSize: 18,
    fontWeight: '700',
    letterSpacing: -0.3,
    marginTop: 8,
  },
  statLabel: { fontSize: 11, fontWeight: '500' },
  quickActions: { gap: 0 },
  actionRow: { flexDirection: 'row', gap: 8 },
  quickAction: {
    flex: 1,
    minHeight: 81,
    borderWidth: 1,
    borderRadius: 15,
    padding: 12,
    justifyContent: 'space-between',
  },
  quickLabel: { fontSize: 11, lineHeight: 14, fontWeight: '600' },
  link: { fontSize: 12, fontWeight: '700' },
  orderRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 13 },
  orderDot: { width: 8, height: 8, borderRadius: 4 },
  orderDetails: { flex: 1, gap: 4 },
  orderCustomer: { fontSize: 13, fontWeight: '700' },
  orderMeta: { fontSize: 11 },
  orderTrailing: { alignItems: 'flex-end', gap: 5 },
  orderAmount: { fontSize: 13, fontWeight: '700' },
  lowStockRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 11 },
  shoeIcon: {
    width: 34,
    height: 34,
    borderRadius: 11,
    backgroundColor: '#F9E9E6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  noAlert: { fontSize: 13, paddingVertical: 10 },
});
