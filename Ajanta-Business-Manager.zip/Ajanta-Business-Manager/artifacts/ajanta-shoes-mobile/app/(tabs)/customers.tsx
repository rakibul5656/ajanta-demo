import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { useBusiness } from '@/src/business-context';
import { customerDue, formatBDT } from '@/src/business';
import { BrandHeader, EmptyState, Page, Panel } from '@/src/ui';

export default function CustomersScreen() {
  const colors = useColors();
  const { data } = useBusiness();
  const [search, setSearch] = useState('');
  const customers = useMemo(() => {
    const term = search.toLowerCase().trim();
    return data.customers.filter(
      (customer) =>
        !term ||
        `${customer.name} ${customer.phone} ${customer.code}`.toLowerCase().includes(term),
    );
  }, [data.customers, search]);
  const outstanding = data.customers.reduce(
    (sum, customer) => sum + customerDue(data, customer.id),
    0,
  );

  return (
    <Page>
      <BrandHeader title="Customers" subtitle={`${data.customers.length} wholesale accounts`} />
      <Panel style={styles.dueSummary}>
        <View style={[styles.dueIcon, { backgroundColor: '#F9E9E6' }]}>
          <Feather name="credit-card" size={19} color={colors.primary} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.dueLabel, { color: colors.mutedForeground }]}>TOTAL CUSTOMER DUE</Text>
          <Text style={[styles.dueTotal, { color: colors.foreground }]}>{formatBDT(outstanding)}</Text>
        </View>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Add customer"
          testID="customers-add"
          onPress={() => router.push('/new-customer')}
          style={({ pressed }) => [
            styles.addButton,
            { backgroundColor: colors.primary, opacity: pressed ? 0.8 : 1 },
          ]}
        >
          <Feather name="plus" size={19} color="#FFFFFF" />
        </Pressable>
      </Panel>
      <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Feather name="search" size={17} color={colors.mutedForeground} />
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder="Search name, code, or phone"
          placeholderTextColor={colors.mutedForeground}
          style={[styles.searchInput, { color: colors.foreground }]}
          returnKeyType="search"
          testID="customers-search"
        />
      </View>
      {customers.length ? (
        customers.map((customer, index) => {
          const due = customerDue(data, customer.id);
          const orderCount = data.orders.filter((order) => order.customerId === customer.id).length;
          return (
            <Panel key={customer.id} style={styles.customerCard}>
              <View style={styles.customerTop}>
                <View style={[styles.avatar, { backgroundColor: index % 2 ? '#F2EAE0' : colors.accent }]}>
                  <Text style={[styles.avatarText, { color: colors.primary }]}>
                    {customer.name.slice(0, 1).toUpperCase()}
                  </Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.customerName, { color: colors.foreground }]}>{customer.name}</Text>
                  <Text style={[styles.customerCode, { color: colors.mutedForeground }]}>
                    {customer.code} · {orderCount} {orderCount === 1 ? 'order' : 'orders'}
                  </Text>
                </View>
                <View style={styles.dueBlock}>
                  <Text style={[styles.customerCode, { color: colors.mutedForeground }]}>DUE</Text>
                  <Text style={[styles.dueValue, { color: due > 0 ? colors.primary : '#397654' }]}>
                    {formatBDT(due)}
                  </Text>
                </View>
              </View>
              <View style={[styles.contactLine, { borderTopColor: colors.border }]}>
                <Feather name="phone" size={13} color={colors.mutedForeground} />
                <Text style={[styles.contactText, { color: colors.mutedForeground }]}>{customer.phone}</Text>
                <Feather name="map-pin" size={13} color={colors.mutedForeground} />
                <Text style={[styles.contactText, { color: colors.mutedForeground, flex: 1 }]} numberOfLines={1}>
                  {customer.address || 'Address not added'}
                </Text>
              </View>
            </Panel>
          );
        })
      ) : (
        <EmptyState
          icon="users"
          title="No customers found"
          description="Add a wholesale customer or adjust your search."
        />
      )}
    </Page>
  );
}

const styles = StyleSheet.create({
  dueSummary: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  dueIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  dueLabel: { fontSize: 10, letterSpacing: 0.7, fontWeight: '700' },
  dueTotal: { fontSize: 21, fontWeight: '700', marginTop: 3 },
  addButton: { width: 39, height: 39, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  searchBox: { height: 48, borderWidth: 1, borderRadius: 14, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 9 },
  searchInput: { flex: 1, paddingVertical: 0, fontSize: 13 },
  customerCard: { padding: 14, gap: 12 },
  customerTop: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  avatar: { width: 41, height: 41, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 17, fontWeight: '700' },
  customerName: { fontSize: 13, fontWeight: '700' },
  customerCode: { fontSize: 10, marginTop: 4 },
  dueBlock: { alignItems: 'flex-end' },
  dueValue: { fontSize: 13, fontWeight: '700', marginTop: 4 },
  contactLine: { borderTopWidth: 1, paddingTop: 10, flexDirection: 'row', alignItems: 'center', gap: 6 },
  contactText: { fontSize: 11, marginRight: 4 },
});
