import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { useBusiness } from '@/src/business-context';
import { formatBDT, formatBusinessDate, orderTotal, paidForOrder } from '@/src/business';
import { ActionButton, BrandHeader, EmptyState, Page, Panel, StatusPill } from '@/src/ui';

export default function OrdersScreen() {
  const colors = useColors();
  const { data } = useBusiness();
  const [filter, setFilter] = useState<'All' | 'Open' | 'Delivered'>('All');
  const orders = useMemo(
    () =>
      data.orders.filter((order) => {
        if (filter === 'Open') return ['Confirmed', 'Packed', 'Dispatched'].includes(order.status);
        if (filter === 'Delivered') return order.status === 'Delivered';
        return true;
      }),
    [data.orders, filter],
  );

  return (
    <Page>
      <BrandHeader title="Sales orders" subtitle="Orders, payments, and delivery" />
      <ActionButton
        title="Create order"
        icon="plus"
        testID="orders-create"
        onPress={() => router.push('/new-order')}
      />
      <View style={styles.filters}>
        {(['All', 'Open', 'Delivered'] as const).map((label) => (
          <Pressable
            key={label}
            onPress={() => setFilter(label)}
            style={[
              styles.filterPill,
              {
                backgroundColor: filter === label ? colors.primary : colors.card,
                borderColor: filter === label ? colors.primary : colors.border,
              },
            ]}
          >
            <Text style={{ color: filter === label ? '#FFFFFF' : colors.foreground, fontSize: 12, fontWeight: '700' }}>
              {label}
            </Text>
          </Pressable>
        ))}
      </View>
      {orders.length ? (
        orders.map((order) => {
          const customer = data.customers.find((entry) => entry.id === order.customerId);
          const total = orderTotal(order);
          const paid = paidForOrder(data, order.id);
          return (
            <Pressable
              accessibilityRole="button"
              key={order.id}
              onPress={() => router.push(`/order/${order.id}`)}
            >
              <Panel style={styles.orderCard}>
                <View style={styles.orderTop}>
                  <View>
                    <Text style={[styles.orderNumber, { color: colors.foreground }]}>{order.orderNo}</Text>
                    <Text style={[styles.orderDate, { color: colors.mutedForeground }]}>
                      {formatBusinessDate(new Date(order.createdAt))}{' '}
                      · {order.channel}
                    </Text>
                  </View>
                  <StatusPill label={order.status} />
                </View>
                <View style={[styles.divider, { backgroundColor: colors.border }]} />
                <View style={styles.customerLine}>
                  <View style={[styles.customerAvatar, { backgroundColor: colors.accent }]}>
                    <Feather name="user" size={16} color={colors.primary} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.customerName, { color: colors.foreground }]}>{customer?.name ?? 'Customer'}</Text>
                    <Text style={[styles.orderDate, { color: colors.mutedForeground }]}>
                      {order.items.length} {order.items.length === 1 ? 'line' : 'lines'} · {order.items.reduce((sum, item) => sum + item.quantity, 0)} pairs
                    </Text>
                  </View>
                  <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
                </View>
                <View style={styles.amountLine}>
                  <View>
                    <Text style={[styles.orderDate, { color: colors.mutedForeground }]}>Order total</Text>
                    <Text style={[styles.total, { color: colors.foreground }]}>{formatBDT(total)}</Text>
                  </View>
                  <View style={{ alignItems: 'flex-end' }}>
                    <Text style={[styles.orderDate, { color: colors.mutedForeground }]}>
                      Due {formatBDT(Math.max(0, total - paid))}
                    </Text>
                    {paid > 0 ? <Text style={[styles.paidLabel, { color: '#397654' }]}>Partial payment</Text> : null}
                  </View>
                </View>
              </Panel>
            </Pressable>
          );
        })
      ) : (
        <EmptyState
          icon="file-text"
          title="No orders in this view"
          description="New sales orders will appear here."
        />
      )}
    </Page>
  );
}

const styles = StyleSheet.create({
  filters: { flexDirection: 'row', gap: 8 },
  filterPill: { borderWidth: 1, borderRadius: 30, paddingHorizontal: 14, paddingVertical: 9 },
  orderCard: { gap: 12 },
  orderTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  orderNumber: { fontSize: 14, fontWeight: '700' },
  orderDate: { fontSize: 11, marginTop: 4 },
  divider: { height: 1 },
  customerLine: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  customerAvatar: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  customerName: { fontSize: 13, fontWeight: '600' },
  amountLine: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  total: { fontSize: 16, fontWeight: '700', marginTop: 3 },
  paidLabel: { fontSize: 10, fontWeight: '700', marginTop: 3 },
});
