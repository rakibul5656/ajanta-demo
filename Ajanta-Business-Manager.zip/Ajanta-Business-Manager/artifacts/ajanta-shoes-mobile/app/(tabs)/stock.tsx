import { Feather } from '@expo/vector-icons';
import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { useBusiness } from '@/src/business-context';
import { formatBDT } from '@/src/business';
import { BrandHeader, EmptyState, Page, Panel, StatusPill } from '@/src/ui';

export default function StockScreen() {
  const colors = useColors();
  const { data, isReady } = useBusiness();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'All' | 'Available' | 'Low stock'>('All');
  const variants = useMemo(() => {
    const normalized = search.trim().toLowerCase();
    return data.variants.filter((variant) => {
      const matchesText =
        !normalized ||
        [variant.modelCode, variant.modelName, variant.sku, variant.color, variant.size]
          .join(' ')
          .toLowerCase()
          .includes(normalized);
      const available = variant.stock - variant.reserved;
      const matchesFilter =
        filter === 'All' ||
        (filter === 'Available' && available > 0) ||
        (filter === 'Low stock' && available <= 5);
      return matchesText && matchesFilter;
    });
  }, [data.variants, filter, search]);
  const totalPairs = data.variants.reduce((sum, variant) => sum + variant.stock, 0);
  const lowCount = data.variants.filter(
    (variant) => variant.stock - variant.reserved <= 5,
  ).length;

  return (
    <Page>
      <BrandHeader title="Stock" subtitle="Your showroom inventory" />
      <View style={styles.summaryRow}>
        <Panel style={styles.summaryCard}>
          <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>TOTAL PAIRS</Text>
          <Text style={[styles.summaryValue, { color: colors.foreground }]}>{totalPairs}</Text>
        </Panel>
        <Panel style={styles.summaryCard}>
          <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>LOW STOCK</Text>
          <Text style={[styles.summaryValue, { color: colors.primary }]}>{lowCount}</Text>
        </Panel>
      </View>
      <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Feather name="search" size={17} color={colors.mutedForeground} />
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder="Search model, SKU, color, size"
          placeholderTextColor={colors.mutedForeground}
          style={[styles.searchInput, { color: colors.foreground }]}
          returnKeyType="search"
          testID="stock-search"
        />
        {search.length > 0 ? (
          <Pressable accessibilityLabel="Clear search" onPress={() => setSearch('')}>
            <Feather name="x-circle" size={17} color={colors.mutedForeground} />
          </Pressable>
        ) : null}
      </View>
      <View style={styles.filters}>
        {(['All', 'Available', 'Low stock'] as const).map((label) => (
          <Pressable
            key={label}
            accessibilityRole="button"
            accessibilityState={{ selected: filter === label }}
            onPress={() => setFilter(label)}
            style={[
              styles.filterPill,
              {
                backgroundColor: filter === label ? colors.primary : colors.card,
                borderColor: filter === label ? colors.primary : colors.border,
              },
            ]}
          >
            <Text style={{ color: filter === label ? '#FFFFFF' : colors.foreground, fontSize: 12, fontWeight: '700' }}>
              {label}
            </Text>
          </Pressable>
        ))}
      </View>
      {!isReady ? (
        <Panel><Text style={{ color: colors.mutedForeground }}>Loading inventory…</Text></Panel>
      ) : variants.length ? (
        variants.map((variant) => {
          const available = variant.stock - variant.reserved;
          const low = available <= 5;
          return (
            <Panel key={variant.id} style={styles.variantCard}>
              <View style={[styles.variantIcon, { backgroundColor: '#F9E9E6' }]}>
                <Feather name="package" size={19} color={colors.primary} />
              </View>
              <View style={styles.variantMain}>
                <View style={styles.variantTitleRow}>
                  <Text style={[styles.modelName, { color: colors.foreground }]}>{variant.modelName}</Text>
                  {low ? <StatusPill label="Low stock" /> : null}
                </View>
                <Text style={[styles.variantSub, { color: colors.mutedForeground }]}>
                  {variant.modelCode} · {variant.color} · size {variant.size}
                </Text>
                <Text style={[styles.sku, { color: colors.mutedForeground }]}>{variant.sku}</Text>
                <View style={[styles.variantBottom, { borderTopColor: colors.border }]}>
                  <Text style={[styles.price, { color: colors.foreground }]}>{formatBDT(variant.wholesalePrice)} / pair</Text>
                  <Text style={[styles.available, { color: low ? colors.primary : '#397654' }]}>
                    {available} available
                  </Text>
                </View>
              </View>
            </Panel>
          );
        })
      ) : (
        <EmptyState
          icon="search"
          title="No matching stock"
          description="Try a different search or inventory filter."
        />
      )}
    </Page>
  );
}

const styles = StyleSheet.create({
  summaryRow: { flexDirection: 'row', gap: 12 },
  summaryCard: { flex: 1, paddingVertical: 14, gap: 8 },
  summaryLabel: { fontSize: 10, fontWeight: '700', letterSpacing: 0.8 },
  summaryValue: { fontSize: 24, fontWeight: '700' },
  searchBox: { height: 48, borderWidth: 1, borderRadius: 14, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 9 },
  searchInput: { flex: 1, paddingVertical: 0, fontSize: 13 },
  filters: { flexDirection: 'row', gap: 8 },
  filterPill: { borderWidth: 1, borderRadius: 30, paddingHorizontal: 14, paddingVertical: 9 },
  variantCard: { flexDirection: 'row', gap: 12, padding: 14 },
  variantIcon: { width: 39, height: 39, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  variantMain: { flex: 1 },
  variantTitleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 6 },
  modelName: { fontSize: 14, fontWeight: '700', flex: 1 },
  variantSub: { fontSize: 12, marginTop: 4 },
  sku: { fontSize: 10, marginTop: 4, letterSpacing: 0.2 },
  variantBottom: { borderTopWidth: 1, marginTop: 10, paddingTop: 9, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  price: { fontSize: 12, fontWeight: '600' },
  available: { fontSize: 11, fontWeight: '700' },
});
