import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useMemo, useState } from 'react';
import {
  Alert,
  Keyboard,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import { useBusiness } from '@/src/business-context';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  formatBDT,
  formatBusinessDate,
  orderTotal,
  paidForOrder,
  type PaymentMethod,
} from '@/src/business';
import { StatusPill } from '@/src/ui';

const methods: PaymentMethod[] = ['Cash', 'Bank', 'bKash', 'Nagad', 'Other'];

export default function OrderDetailScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id: routeId } = useLocalSearchParams<{ id: string }>();
  const id = Array.isArray(routeId) ? routeId[0] : routeId;
  const { data, recordPayment, updateOrderStatus } = useBusiness();
  const order = data.orders.find((entry) => entry.id === id);
  const customer = data.customers.find((entry) => entry.id === order?.customerId);
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<PaymentMethod>('Cash');
  const [error, setError] = useState('');
  const total = order ? orderTotal(order) : 0;
  const paid = order ? paidForOrder(data, order.id) : 0;
  const due = Math.max(0, total - paid);
  const payments = useMemo(
    () => data.payments.filter((payment) => payment.orderId === id),
    [data.payments, id],
  );

  if (!order) {
    return (
      <View style={[styles.root, styles.center, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: '700' }}>
          Order not found
        </Text>
        <Pressable onPress={() => router.back()} style={{ padding: 14 }}>
          <Text style={{ color: colors.primary, fontWeight: '700' }}>Go back</Text>
        </Pressable>
      </View>
    );
  }

  const customerName = customer?.name ?? 'Customer';
  const changeStatus = (status: typeof order.status) => {
    setError('');
    try {
      updateOrderStatus(order.id, status);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Could not update order.');
    }
  };

  const cancelOrder = () => {
    const confirm = () => changeStatus('Cancelled');
    if (Platform.OS === 'web') {
      if (globalThis.confirm('Cancel this order? Reserved stock will be released.')) {
        confirm();
      }
      return;
    }
    Alert.alert('Cancel order?', 'Reserved stock will be released.', [
      { text: 'Keep order', style: 'cancel' },
      { text: 'Cancel order', style: 'destructive', onPress: confirm },
    ]);
  };

  const collectPayment = () => {
    setError('');
    const parsedAmount = Number(amount);
    try {
      recordPayment(order.id, parsedAmount, method);
      setAmount('');
      Keyboard.dismiss();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Could not record payment.');
    }
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.topBar,
          {
            paddingTop: Platform.OS === 'web' ? 67 : insets.top + 12,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Go back"
          onPress={() => router.back()}
          style={styles.backButton}
        >
          <Feather name="arrow-left" size={20} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.topTitle, { color: colors.foreground }]}>Order details</Text>
        <View style={{ width: 40 }} />
      </View>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={{
          padding: 18,
          paddingBottom: 50,
          gap: 15,
        }}
        bottomOffset={72}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.orderHeading}>
          <View style={{ gap: 5 }}>
            <Text style={[styles.orderNo, { color: colors.foreground }]}>{order.orderNo}</Text>
            <Text style={[styles.meta, { color: colors.mutedForeground }]}>
              {new Date(order.createdAt).toLocaleString('en-BD', {
                timeZone: 'Asia/Dhaka',
                day: 'numeric',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })}{' '}
              · {order.channel}
            </Text>
          </View>
          <StatusPill label={order.status} />
        </View>

        <View style={[styles.totalCard, { backgroundColor: '#8D171D' }]}>
          <View style={styles.totalTop}>
            <View>
              <Text style={styles.totalCaption}>TOTAL AMOUNT</Text>
              <Text style={styles.totalNumber}>{formatBDT(total)}</Text>
            </View>
            <View style={styles.dueBox}>
              <Text style={styles.dueCaption}>REMAINING DUE</Text>
              <Text style={styles.dueNumber}>{formatBDT(due)}</Text>
            </View>
          </View>
          <View style={styles.paidTrack}>
            <View style={[styles.paidProgress, { width: `${total ? Math.min(100, (paid / total) * 100) : 0}%` }]} />
          </View>
          <Text style={styles.paidCaption}>{formatBDT(paid)} received</Text>
        </View>

        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Customer</Text>
          <View style={styles.customerRow}>
            <View style={[styles.customerGlyph, { backgroundColor: colors.accent }]}>
              <Feather name="user" size={17} color={colors.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.customerName, { color: colors.foreground }]}>{customerName}</Text>
              <Text style={[styles.meta, { color: colors.mutedForeground }]}>
                {customer?.phone ?? 'Phone not added'}
              </Text>
            </View>
          </View>
          {order.notes ? (
            <Text style={[styles.note, { color: colors.mutedForeground }]}>
              “{order.notes}”
            </Text>
          ) : null}
        </View>

        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Items</Text>
          {order.items.map((line, index) => (
            <View
              key={`${line.variantId}-${index}`}
              style={[
                styles.itemRow,
                index > 0 && { borderTopWidth: 1, borderTopColor: colors.border },
              ]}
            >
              <View style={{ flex: 1 }}>
                <Text style={[styles.itemName, { color: colors.foreground }]}>{line.modelName}</Text>
                <Text style={[styles.meta, { color: colors.mutedForeground }]}>
                  {line.color} · size {line.size} · {line.sku}
                </Text>
                <Text style={[styles.meta, { color: colors.mutedForeground }]}>
                  {line.quantity} pairs × {formatBDT(line.unitPrice)}
                </Text>
              </View>
              <Text style={[styles.itemTotal, { color: colors.foreground }]}>
                {formatBDT((line.unitPrice - line.discount) * line.quantity)}
              </Text>
            </View>
          ))}
          <View style={[styles.subtotalRow, { borderTopColor: colors.border }]}>
            <Text style={[styles.meta, { color: colors.mutedForeground }]}>Order total</Text>
            <Text style={[styles.totalText, { color: colors.foreground }]}>{formatBDT(total)}</Text>
          </View>
        </View>

        {order.status !== 'Cancelled' && order.status !== 'Delivered' && order.status !== 'Dispatched' ? (
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, gap: 11 }]}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Order progress</Text>
            {order.status === 'Confirmed' ? (
              <Action
                title="Mark as packed"
                icon="archive"
                onPress={() => changeStatus('Packed')}
              />
            ) : null}
            {order.status === 'Confirmed' || order.status === 'Packed' ? (
              <Action
                title="Mark as dispatched"
                icon="truck"
                onPress={() => changeStatus('Dispatched')}
              />
            ) : null}
            <Pressable
              accessibilityRole="button"
              onPress={cancelOrder}
              style={[styles.cancelButton, { borderColor: colors.border }]}
            >
              <Feather name="x-circle" size={16} color={colors.destructive} />
              <Text style={{ color: colors.destructive, fontSize: 12, fontWeight: '700' }}>
                Cancel order
              </Text>
            </Pressable>
          </View>
        ) : order.status === 'Dispatched' ? (
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.sectionTitle, { color: colors.foreground, marginBottom: 12 }]}>
              Delivery
            </Text>
            <Action
              title="Confirm delivery"
              icon="check-circle"
              onPress={() => changeStatus('Delivered')}
            />
          </View>
        ) : null}

        {error ? (
          <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text>
        ) : null}

        {due > 0 && order.status !== 'Cancelled' ? (
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, gap: 12 }]}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Record a payment</Text>
            <TextInput
              testID="payment-amount"
              value={amount}
              onChangeText={setAmount}
              placeholder="Amount in BDT"
              placeholderTextColor={colors.mutedForeground}
              keyboardType="decimal-pad"
              style={[styles.input, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }]}
            />
            <View style={styles.methodRow}>
              {methods.map((entry) => (
                <Pressable
                  key={entry}
                  onPress={() => setMethod(entry)}
                  style={[
                    styles.methodPill,
                    {
                      backgroundColor: method === entry ? colors.primary : colors.background,
                      borderColor: method === entry ? colors.primary : colors.border,
                    },
                  ]}
                >
                  <Text style={{ color: method === entry ? '#FFFFFF' : colors.foreground, fontSize: 10, fontWeight: '700' }}>
                    {entry}
                  </Text>
                </Pressable>
              ))}
            </View>
            <Action title="Save payment" icon="check" onPress={collectPayment} />
          </View>
        ) : null}

        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Payment history</Text>
          {payments.length ? (
            payments.map((payment, index) => (
              <View
                key={payment.id}
                style={[
                  styles.paymentRow,
                  index > 0 && { borderTopWidth: 1, borderTopColor: colors.border },
                ]}
              >
                <View style={[styles.paymentGlyph, { backgroundColor: '#E8F2EC' }]}>
                  <Feather name="arrow-down-left" size={15} color="#397654" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.customerName, { color: colors.foreground }]}>{payment.method}</Text>
                  <Text style={[styles.meta, { color: colors.mutedForeground }]}>
                    {formatBusinessDate(new Date(payment.createdAt))}
                  </Text>
                </View>
                <Text style={[styles.itemTotal, { color: '#397654' }]}>{formatBDT(payment.amount)}</Text>
              </View>
            ))
          ) : (
            <Text style={[styles.meta, { color: colors.mutedForeground, paddingVertical: 12 }]}>
              No payment has been recorded for this order.
            </Text>
          )}
        </View>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

function Action({
  title,
  icon,
  onPress,
}: {
  title: string;
  icon: React.ComponentProps<typeof Feather>['name'];
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [
        styles.actionButton,
        { backgroundColor: colors.primary, opacity: pressed ? 0.82 : 1 },
      ]}
    >
      <Feather name={icon} size={16} color="#FFFFFF" />
      <Text style={styles.actionText}>{title}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  center: { alignItems: 'center', justifyContent: 'center' },
  topBar: {
    minHeight: 59,
    paddingHorizontal: 18,
    paddingBottom: 12,
    borderBottomWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  topTitle: { fontSize: 16, fontWeight: '700' },
  orderHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  orderNo: { fontSize: 23, fontWeight: '700', letterSpacing: -0.4 },
  meta: { fontSize: 11, lineHeight: 16, marginTop: 3 },
  totalCard: { borderRadius: 17, padding: 17, gap: 13 },
  totalTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  totalCaption: { color: '#F3CFCA', fontSize: 10, fontWeight: '700', letterSpacing: 0.9 },
  totalNumber: { color: '#FFFFFF', fontSize: 26, fontWeight: '700', marginTop: 5 },
  dueBox: { alignItems: 'flex-end' },
  dueCaption: { color: '#F3CFCA', fontSize: 9, fontWeight: '700', letterSpacing: 0.7 },
  dueNumber: { color: '#FFFFFF', fontSize: 18, fontWeight: '700', marginTop: 5 },
  paidTrack: { height: 5, borderRadius: 3, backgroundColor: '#B04B50', overflow: 'hidden' },
  paidProgress: { height: 5, backgroundColor: '#F3D4B4', borderRadius: 3 },
  paidCaption: { color: '#E8B8B5', fontSize: 10 },
  card: { borderWidth: 1, borderRadius: 16, padding: 15 },
  sectionTitle: { fontSize: 14, fontWeight: '700' },
  customerRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 12 },
  customerGlyph: { width: 37, height: 37, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  customerName: { fontSize: 12, fontWeight: '700' },
  note: { fontSize: 12, lineHeight: 18, marginTop: 12 },
  itemRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, gap: 8 },
  itemName: { fontSize: 12, fontWeight: '700' },
  itemTotal: { fontSize: 12, fontWeight: '700' },
  subtotalRow: { borderTopWidth: 1, paddingTop: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  totalText: { fontSize: 14, fontWeight: '700' },
  cancelButton: { borderWidth: 1, minHeight: 44, borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  input: { minHeight: 46, borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, fontSize: 13 },
  methodRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  methodPill: { borderWidth: 1, borderRadius: 20, paddingHorizontal: 9, paddingVertical: 7 },
  error: { fontSize: 12, fontWeight: '600' },
  actionButton: { minHeight: 44, borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  actionText: { color: '#FFFFFF', fontSize: 12, fontWeight: '700' },
  paymentRow: { flexDirection: 'row', alignItems: 'center', gap: 9, paddingVertical: 10 },
  paymentGlyph: { width: 31, height: 31, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
});
