/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#221B1B',
    tint: '#B51E26',

    // Core surfaces
    background: '#F8F5F1',
    foreground: '#221B1B',

    // Cards / elevated surfaces
    card: '#FFFFFF',
    cardForeground: '#221B1B',

    // Primary action color (buttons, links, active states)
    primary: '#B51E26',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#F0E9E3',
    secondaryForeground: '#463B39',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#F0E9E3',
    mutedForeground: '#817572',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#F9E9E6',
    accentForeground: '#8F171D',

    // Destructive actions (delete, error states)
    destructive: '#B42318',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#E9E1DB',
    input: '#E9E1DB',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 16,
};

export default colors;
