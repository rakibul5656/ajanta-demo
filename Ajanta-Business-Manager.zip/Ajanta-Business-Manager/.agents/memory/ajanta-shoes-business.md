---
name: Ajanta Shoes business context
description: Business background and operating assumptions supplied for the Ajanta Shoes wholesale management system.
---

Ajanta Shoes is an existing wholesale footwear seller and distributor in Dhaka, Bangladesh. Its operation is based at Dhaka Trade Center in Gulistan. It buys from factories and suppliers, tracks footwear by model, color, and shoe size, and sells to dealers. The starting team is about 2–5 staff members; most existing records are paper ledgers.

Use Bangladeshi Taka (BDT) for money and Asia/Dhaka for business dates and times. Treat imported opening balances and paper-ledger history as unverified until reconciled; never invent historical business records.

**Why:** These operating facts are not fully discoverable from the app code and shape meaningful inventory, accounting, and migration decisions.

**How to apply:** Keep them as defaults in future Ajanta Shoes product work, and ask before changing the business timezone or currency.
